class JawrUrlMappings {
    static mappings = {
      "/**.js"(controller:'jawrJavascript')
      "/**.css"(controller:'jawrCSS')
	}
}
